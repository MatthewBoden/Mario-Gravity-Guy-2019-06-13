#########################################
# File Name: PlatformExample.py      Call the game Mario Runner
# Description: Demonstrates how to use a platform to support an object under gravity
# Author: ICS2O
# Date: 12/12/2017
#########################################
import pygame
import random

pygame.init()
WIDTH = 800
HEIGHT = 600
gameWindow = pygame.display.set_mode((WIDTH, HEIGHT))
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
OUTLINE = 0
# ---------------------------------------#
# functions                             #
# ---------------------------------------#


def redrawGameWindow(gameWindow):
    background1.draw(gameWindow)
    background2.draw(gameWindow)
    levels[chs_tile].draw(gameWindow)
    #levels[chs2_tile].draw(gameWindow)
    player1.draw(gameWindow)
    pygame.display.update()

def text_objects(text,font,colour):
    textSurface = font.render(text,True,colour)
    return textSurface, textSurface.get_rect()

def txt(text,x,y,size,colour):     # custom text function with custom font
    largeText = pygame.font.Font("RODAMAS.otf",size)
    TextSurf, TextRect = text_objects(text,largeText,colour)
    TextRect.center = (x,y)
    gameWindow.blit(TextSurf,TextRect)
    pygame.display.update()

def start_screen():
    gameWindow.blit(backroundstart, (0, 0))
    txt("BENDING\n SPACE-TIME\n BOI", 400, 50, 200, RED)
    txt("CLICK SPACE TO START ONE PLAYER", 400, 250, 150, RED)
    txt("CLICK RETURN TO START TWO PLAYER", 400, 250, 150, RED)
    pygame.display.update()

def end_screen():
    gameWindow.blit(backgroundend, (0, 0))
    txt("GAME OVER", 400 , 50, 200, RED)
    txt("SCORE", 400, 300, 100, RED)     #
    txt("YOU DID NOT BED SPACE-TIME BOI", 400, 300, 100, RED)  #
    #text = font.render(str(score), 1, RED)  # put the font and the message together
    #screen.blit(text, (400, 350))   # draw it on the screen at the text_X and text_Y



# ---------------------------------------#
#   classes                              #
# ---------------------------------------#
class Player():
    '''

    '''
    def __init__(self,marioX,marioY,marioVx,marioVy,marioPic):
        self.mario = pygame.image.load("images/mario1.png")
        self.marioH = 63  #
        self.marioW = 33  #
        self.marioX = marioX  # dimensions of mario
        self.marioY = marioY  #
        self.marioVx = marioVx  #
        self.marioVy = marioVy  #
        self.marioPicNum = 1  # current picture of mario
        self.marioDir = "left"  # direction in which mario is facing
        self.marioPic = [0] * 12  # 12 pictures represent all animated views of mario
        for i in range(12):  # these pictures must be in the same folder
            self.marioPic[i] = pygame.image.load("images/" + marioPic + str(i) + ".png")

        self.nextLeftPic = [1, 2, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1]
        self.nextRightPic = [4, 4, 4, 4, 5, 6, 7, 5, 4, 4, 4, 4]
    def draw(self, gameWindow):
        gameWindow.blit(self.marioPic[self.marioPicNum], (self.marioX, self.marioY))

    def collide(self, other):
        if pygame.Rect(self.marioX, self.marioY, self.marioW, self.marioH).colliderect(other.x, other.y, other.w, other.h):
            return True

    def flip(self):
        for i in range(len(self.marioPic)):
            self.marioPic[i] = pygame.transform.flip(self.marioPic[i], False, True)

class Tile():
    '''
    This class is the structure of the tiles and platforms.
    Each of the tiles will be apart of a section and the
    sections will be called randomly to challenge the player.
    '''

    def __init__(self,x,y,w,h):
        self.x = x
        self.y = y
        self.w = w
        self.h = h

    def draw(self, gameWindow):
        pygame.draw.rect(gameWindow, BLACK, (self.x, self.y, self.w, self.h))

    def move_tile(self, speed):
        self.x -= speed

class Level():
    def __init__(self, number, tileL):
        self.number=number
        self.tileList=tileL
        self.passLevel=False

    def draw(self, gameWindow):
        for i in self.tileList:
            i.draw(gameWindow)
    def move(self, speed):
        for i in self.tileList:
            i.move_tile(speed)

class Sprite(pygame.sprite.Sprite):
    """ (fileName)
        Visible game object.
        Inherits Sprite to use its Rect property.
        See Sprite documentation here:
        http://www.pygame.org/docs/ref/sprite.html#pygame.sprite.Sprite
    """

    def __init__(self, picture=None, x=0, y=0, speed=0):
        pygame.sprite.Sprite.__init__(self)
        self.x = x
        self.y = y
        self.speed = speed
        self.visible = False
        image1 = pygame.image.load(picture)
        self.image = pygame.transform.scale(image1, (800, 600))
        self.rect = self.image.get_rect()  # each sprite has a rect attribute - a list of 4 numbers: left, top, width, height
        self.update()

    def spawn(self, x, y):
        """ Assign coordinates to the center of the object and make it visible.
        """
        self.x = x - self.rect.width / 2
        self.y = y - self.rect.height / 2
        self.rect = pygame.Rect(self.x, self.y, self.rect.width, self.rect.height)
        self.visible = True
        self.update()

    def draw(self, surface):
        surface.blit(self.image, self.rect)

    def update(self):  # after moving a sprite, the rect attribute must be updated
        self.rect = pygame.Rect(self.x, self.y, self.rect.width, self.rect.height)

    def moveLeft(self, shift):
        self.x -= shift
        self.update()

    def moveRight(self, shift):
        self.x += shift
        self.update()

    def moveUp(self, shift):
        self.y -= shift
        self.update()

    def moveDown(self, shift):
        self.y += shift
        self.update()


# ---------------------------------------#
# main program                           #
# ---------------------------------------#


#### These are all of the starting segments####


# random_top_y = random.randrange(100,300, 50)
# #random_top_x =
# #random_top_w =
# random_top_h = 50
#
# random_bottom_y = random.randrange(400,600, 50)
#random_bottom_x =
#random_bottom_w =
# random_bottom_h = 50

tiles1 = [Tile(0, 100, 300, 50), Tile(400, 100, 300, 50), Tile(0, 450, 400, 50),
          Tile(500, 450, 400, 50), Tile(600, 225, 50, 150), Tile(200, 225, 50, 150)]
#    return tiles1



tiles2 = [Tile(0, 400, 800, 50), Tile(0, 200, 800, 50), Tile(200, 350, 50, 50),
          Tile(350, 250, 50, 50), Tile(500, 350, 50, 50), Tile(650, 250, 50, 50)]
#    return tiles2



tiles3 = [Tile(0, 100, 800, 50), Tile(200, 150, 400, 50), Tile(300, 200, 200, 50),
          Tile(0, 450, 800, 50), Tile(200, 400, 400, 50), Tile(300, 350, 200, 50)]
#   return tiles3



tiles4 = [Tile(0, 150, 200, 50), Tile(200, 100, 100, 50), Tile(300, 50, 200, 50), Tile(500, 100, 100, 50),
          Tile(600, 150, 200, 50),
          Tile(0, 400, 200, 50), Tile(200, 450, 100, 50), Tile(300, 500, 200, 50), Tile(500, 450, 100, 50),
          Tile(600, 400, 200, 50)]
#   return tiles4



tiles5 = [Tile(0, 100, 800, 50), Tile(0, 450, 800, 50), Tile(150, 225, 50, 150), Tile(450, 225, 50, 150),
          Tile(300, 350, 50, 100), Tile(300, 150, 50, 100), Tile(600, 350, 50, 100), Tile(600, 150, 50, 100)]
#   return tiles5
tiles=(tiles1,tiles2,tiles3, tiles4, tiles5)
levels=[] #list of 5 levels with tiles
for i in range(5):
    level=Level(i+1, tiles[i])
    levels.append(level)
    print(levels[i].number)

chs_tile = random.randint(0,4)
chosenTiles =  levels[chs_tile]

chs2_tile = random.randint(0,4)
chosenTiles2 =  levels[chs2_tile]

JUMP_SPEED = -30
GROUND = HEIGHT   # where the ground is
RUN_SPEED = 5     # The speed of mario
GRAVITY = 2       # The gravity
BACKGROUND_SPEED = 5   # speed of moving backround
background1 = Sprite("backround1.jpg")
background1.spawn(WIDTH/2,HEIGHT/2)
background2 = Sprite("backround2.jpg")
background2.spawn(WIDTH/2+background1.rect.width,HEIGHT/2)
print("Hit ESC to end the program.")
clock = pygame.time.Clock()
FPS = 30
isOnGround = False
player1 = Player(100,300,10,10,"mario")

#---------------------------------------#
inPlay = True
while inPlay:
    redrawGameWindow(gameWindow)
    clock.tick(FPS)

    pygame.event.clear()
    keys = pygame.key.get_pressed()
    if keys[pygame.K_ESCAPE]:
        inPlay = False

    # set horizontal and vertical velocity
    #if keys[pygame.K_LEFT]:
        #player1.marioVx = -RUN_SPEED
        #player1.marioDir = "left"
        #if player1.marioY:
            #player1.marioPicNum = player1.nextLeftPic[player1.marioPicNum]
        #for tile in chosenTiles.tileList:
    #elif keys[pygame.K_RIGHT]:
        #player1.marioVx = RUN_SPEED
        #player1.marioDir = "right"
        #if player1.marioY:
            #player1.marioPicNum = player1.nextRightPic[player1.marioPicNum]
        #for tile in chosenTiles.tileList:
            #if pygame.Rect(player1.marioX, player1.marioY, player1.marioW, player1.marioH).colliderect(tile.x - 5, tile.y + 7, tile.w + 10, tile.h - 14):
                #player1.marioVx = 0
    #else:  # if neither left nor right arrow is pressed
        #player1.marioVx = 0  # mario is in standing still position
        #if player1.marioDir == "left":  # when standing,
            #player1.marioPicNum = 0  # the animation view is either 1 or 5,
       # elif player1.marioDir == "right":  # depending on the direction in which
            #player1.marioPicNum = 4  # mario is facing

    if keys[pygame.K_UP] and isOnGround:
        player1.flip()
        GRAVITY *= -1
        player1.marioY += GRAVITY

        if player1.marioDir == "left":  # when jumping,
            player1.marioPicNum = 8  # the animation view is either 9 or 10,
        elif player1.marioDir == "right":  # depending on the direction in which
            player1.marioPicNum = 9  # mario is facing

    for tile in chosenTiles.tileList:
        isOnGround = player1.collide(tile)
#       if player1.marioX + player1.marioW >= tile.x and player1.marioX + player1.marioW <= tile.x + tile.w:
            #if player1.marioY - 7 + player1.marioH <= tile.y + tile.h and player1.marioY + 7 >= tile.y :
        if isOnGround==True:
            if(GRAVITY>0):
                player1.marioY = tile.y - player1.marioH + 1
            elif(GRAVITY<0):
                player1.marioY = tile.y + tile.h - 1
            break

    if (isOnGround == None):
        isOnGround = False

    if tile.x + tile.w > 0:
        chosenTiles.move(BACKGROUND_SPEED)
    else:
        chs_tile = random.randint(0, 4)
        tile.x += 800
        chosenTiles = levels[chs_tile]  # tiles5


    for tile in chosenTiles.tileList:
        if pygame.Rect(player1.marioX, player1.marioY, player1.marioW, player1.marioH).colliderect(tile.x - 5, tile.y + 7, tile.w + 10, tile.h - 14):
            player1.marioX -= BACKGROUND_SPEED*2

    # move Mario in horizontal direction
    player1.marioX = player1.marioX + player1.marioVx
    # update Mario's vertical velocity


    # move Mario in vertical direction


    if isOnGround:
        player1.marioVy = 0
    else:
        player1.marioVy = player1.marioVy + GRAVITY
        player1.marioY = player1.marioY + player1.marioVy

    background1.moveLeft(BACKGROUND_SPEED)
    if background1.x < -background1.rect.width:
        background1.x = background2.rect.width - BACKGROUND_SPEED
    background2.moveLeft(BACKGROUND_SPEED)
    if background2.x < -background2.rect.width:
        background2.x = background1.rect.width - BACKGROUND_SPEED




        # ---------------------------------------#
pygame.quit()




