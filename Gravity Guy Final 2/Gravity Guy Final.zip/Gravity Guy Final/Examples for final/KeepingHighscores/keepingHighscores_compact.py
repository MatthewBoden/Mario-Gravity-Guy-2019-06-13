#########################################
# File Name: keepingHighscores_compact.py
# Description: This program demonstrates how to handle highscores file.
#               It adds a new score to the list. Inspect the .txt file!
# Author: ICS2OG
# Date: 14/01/2019
#########################################

playerName = input('\n\nPlease enter your name: ')
playerScore = input('What is your score: ')

scoresFile = 'highscores.txt'
tupleList = []

fileIn = open(scoresFile,'r')           #
data = fileIn.read()                    # data = 'score1 name1 score2 name2 ...'
fileIn.close()                          #

allScores = data.split()                # allScores = [score1,name1,score2,name2 ...]
scores = allScores[::2]                 # scores = [score1,score2 ...]
names = allScores[1::2]                 # names = [name1,name2 ...]

for i in range (len(names)):            #
    tup = (int(scores[i]),names[i])     # assemble tuples from int scores and names
    tupleList.append(tup)               # add these tuples to the list

tup = (playerScore, playerName)         # assemble a tuple from player's int score and name
tupleList.append(tup)                   # append it to the back of the list
tupleList.sort(reverse=True)            # sort the list of tuples in descending order 

fileOut = open(scoresFile, 'w')         #  
for i in range(len(tupleList)):         #
    score, name = tupleList[i]          # split a tuple from the list to an int score and a name 
    fileOut.write(str(score)+' '+name+'\n')
    print (str(score)+' '+name   )        # don't forget to convert the int score to str!
fileOut.close()                         #


